def largest_divisor(n):
    for i in range(n, 0, -1):
        if n % i == 0:
            return i
