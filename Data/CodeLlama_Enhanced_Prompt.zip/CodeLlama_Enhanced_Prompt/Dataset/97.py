def multiply(a, b):
    return abs(a % 10) * abs(b % 10)
