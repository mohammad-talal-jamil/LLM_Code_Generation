def odd_count(my_list):
    return ["the number of odd elements in the string {} of the input.".format(str(sum(int(char) % 2 for char in word))) for word in my_list]
