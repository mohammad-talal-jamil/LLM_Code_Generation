def filter_by_prefix(strings, prefix):
    return list(filter(lambda x: x.startswith(prefix), strings))
