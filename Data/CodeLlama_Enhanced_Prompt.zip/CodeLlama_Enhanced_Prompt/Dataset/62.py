def derivative(xs):
    return [x * i for i, x in enumerate(xs[1:], 1)]
