def sum_to_n(n: int) -> int:
    return (n * (n + 1)) // 2
