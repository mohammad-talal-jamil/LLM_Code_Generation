def get_positive(l):
    return [x for x in l if x > 0]
