def solve(N):
    return bin(sum(map(int, str(N))))[2:]
