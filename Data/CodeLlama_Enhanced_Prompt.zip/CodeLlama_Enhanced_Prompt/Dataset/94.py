def get_largest_prime_sum_digits(my_list):
    # TODO: Implement your solution here
    pass
