def incr_list(l):
    """Return list with elements incremented by 1."""
    return [(e + 1) for e in l]

