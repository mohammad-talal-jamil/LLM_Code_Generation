def change_base(x, base):
    return str(bin(x)[2:])
