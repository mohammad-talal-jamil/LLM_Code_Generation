def same_chars(s0: str, s1: str) -> bool:
    return sorted(s0) == sorted(s1)
