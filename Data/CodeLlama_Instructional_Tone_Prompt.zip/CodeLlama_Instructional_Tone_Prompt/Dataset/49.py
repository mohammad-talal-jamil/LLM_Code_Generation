def modp(n: int, p: int):
    return 2 ** n % p
