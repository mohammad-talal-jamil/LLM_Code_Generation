def filter_by_substring(strings, substring):
    return list(filter(lambda x: substring in x, strings))
