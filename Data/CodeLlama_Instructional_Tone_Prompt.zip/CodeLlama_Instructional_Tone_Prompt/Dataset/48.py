def is_palindrome(text: str) -> bool:
    return text == text[::-1]
