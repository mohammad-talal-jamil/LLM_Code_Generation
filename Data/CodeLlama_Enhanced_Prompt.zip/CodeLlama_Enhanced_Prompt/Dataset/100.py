def make_a_pile(n):
    return list(range(n, n*2+1, 2))
