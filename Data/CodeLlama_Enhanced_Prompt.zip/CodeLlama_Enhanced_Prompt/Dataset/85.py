def add(lst):
    return sum(x for x in lst if not x % 2)
