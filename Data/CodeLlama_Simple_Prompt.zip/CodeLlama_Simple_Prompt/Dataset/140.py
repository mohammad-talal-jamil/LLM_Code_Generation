def fix_spaces(text):
    return text.replace(" ", "_").replace("  ", "-")
