def odd_count(lst):
    return ["the number of odd elements " + str(sum(int(d) % 2 == 1 for d in arr)) + "n the str" + str(len(arr)) + "ng " + str(len(arr)) + " of the " + str(len(arr)) + "nput." for arr in lst]
