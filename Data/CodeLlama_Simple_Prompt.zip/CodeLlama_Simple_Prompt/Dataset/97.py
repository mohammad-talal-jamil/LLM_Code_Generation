def multiply(a, b):
    return int(str(a)[-1]) * int(str(b)[-1])
