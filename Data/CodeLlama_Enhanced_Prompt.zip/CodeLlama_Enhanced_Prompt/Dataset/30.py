def get_positive(l: list):
    return list(filter(lambda x: x > 0, l))
