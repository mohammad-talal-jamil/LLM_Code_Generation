def add(x: int, y: int) -> int:
    """Add two numbers x and y"""
    return x + y
