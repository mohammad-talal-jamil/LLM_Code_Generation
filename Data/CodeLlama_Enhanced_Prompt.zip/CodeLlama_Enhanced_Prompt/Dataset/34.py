def unique(l):
    return sorted(list(set(l)))
