def how_many_times(string, substring):
    return string.count(substring)
