def common(l1: list, l2: list):
    return sorted(set(l1).intersection(l2))
