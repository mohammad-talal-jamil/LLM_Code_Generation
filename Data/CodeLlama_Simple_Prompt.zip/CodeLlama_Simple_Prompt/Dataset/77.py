def iscube(a):
    return int(a ** 0.333333) ** 3 == a
