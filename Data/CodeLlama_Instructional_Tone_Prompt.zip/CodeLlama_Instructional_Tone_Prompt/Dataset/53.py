def add(x: int, y: int):
    return x + y
