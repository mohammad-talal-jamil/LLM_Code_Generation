def sum_squares(lst):
    return sum(int(math.ceil(x))**2 for x in lst)
