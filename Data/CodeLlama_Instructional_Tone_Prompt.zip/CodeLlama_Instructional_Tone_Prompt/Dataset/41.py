def car_race_collision(n: int) -> int:
    return n * (n + 1) // 2
