def incr_list(l: list):
    return [x + 1 for x in l]
