def separate_paren_groups(paren_string: str) -> List[str]:
    open_brackets = 0
    start = 0
    result = []
    for i, char in enumerate(paren_string):
        if char == "(":
            if open_brackets == 0:
                start = i
            open_brackets += 1
        elif char == ")":
            open_brackets -= 1
            if open_brackets == 0:
                result.append(paren_string[start:i+1])
    return result
