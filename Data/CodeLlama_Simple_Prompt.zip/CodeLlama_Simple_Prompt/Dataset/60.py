def sum_to_n(n: int) -> int:
    return sum(range(1, n+1))
