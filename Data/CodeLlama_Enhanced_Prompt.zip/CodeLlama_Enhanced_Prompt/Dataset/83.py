def starts_one_ends(n):
    return 2 * (10 ** (n - 1))
