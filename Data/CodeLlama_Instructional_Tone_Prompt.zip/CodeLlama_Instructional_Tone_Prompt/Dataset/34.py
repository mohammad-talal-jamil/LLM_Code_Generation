def unique(l):
    return sorted(set(l))
