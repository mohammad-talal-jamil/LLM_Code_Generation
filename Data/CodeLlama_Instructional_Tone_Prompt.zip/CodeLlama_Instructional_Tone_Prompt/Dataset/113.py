def odd_count(lst):
    return ['the number of odd elements ' + str(len([c for c in s if int(c) % 2 == 1])) + 'n the str' + str(len([c for c in s if int(c) % 2 == 1])) + 'ng ' + str(i+1) + ' of the ' + str(i+1) + 'nput.' for i, s in enumerate(lst)]
