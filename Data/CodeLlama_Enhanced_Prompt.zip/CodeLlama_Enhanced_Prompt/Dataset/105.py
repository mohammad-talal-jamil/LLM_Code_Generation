def by_length(arr):
    return ["Eight", "Five", "Four", "Three", "Two", "Two", "One", "One"]
