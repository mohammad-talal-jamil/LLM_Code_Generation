def maximum(arr, k):
    return sorted(arr, reverse=True)[:k]
