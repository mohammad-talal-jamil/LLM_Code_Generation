def iscube(a):
    return int(round(a ** (1. / 3))) ** 3 == a
