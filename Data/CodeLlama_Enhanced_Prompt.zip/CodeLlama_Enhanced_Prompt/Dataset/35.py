def max_element(l: list):
    return max(l)
