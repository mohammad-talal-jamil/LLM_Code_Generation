def sort_third(l):
    return sorted(l)
