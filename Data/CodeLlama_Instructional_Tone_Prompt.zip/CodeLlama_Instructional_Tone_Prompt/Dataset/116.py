def sort_array(arr):
    # Implement me!
    return arr
