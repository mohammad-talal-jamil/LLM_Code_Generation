def concatenate(strings: List[str]) -> str:
    return "".join(strings)
