def generate_integers(a, b):
    return list(range(max(2, min(a, b)), min(8, max(a, b)) + 1, 2))
