def truncate_number(number: float) -> float:
    return abs(number) % 1
