def flip_case(string):
    return string.swapcase()
