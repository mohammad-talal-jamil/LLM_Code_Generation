def iscube(a):
    return a ** (1 / 3) == int(a ** (1 / 3))
