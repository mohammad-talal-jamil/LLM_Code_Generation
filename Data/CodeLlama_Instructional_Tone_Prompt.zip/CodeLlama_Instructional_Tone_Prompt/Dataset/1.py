def separate_paren_groups(paren_string):
    # Implement the solution here
    pass
