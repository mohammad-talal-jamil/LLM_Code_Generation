def strlen(string):
    return len(string)
