def solve(N):
    return bin(N)[2:]
