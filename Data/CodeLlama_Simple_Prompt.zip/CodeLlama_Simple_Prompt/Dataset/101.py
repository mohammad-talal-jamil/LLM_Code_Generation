def words_string(s):
    return s.split(", ")
