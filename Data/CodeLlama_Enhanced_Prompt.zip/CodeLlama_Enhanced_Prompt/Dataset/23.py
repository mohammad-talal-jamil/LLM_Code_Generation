def strlen(string: str) -> int:
    return len(string)
